package com.backend.adea.org.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.backend.adea.org.entity.Examen;
import com.backend.adea.org.model.dao.IExamenDao;
 

@Service
public class ExamenServiceImpl  implements IExamenService{

	@Autowired
	private IExamenDao examenDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<Examen> findAll() {
		// TODO Auto-generated method stub
		return (List<Examen>) examenDao.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<Examen> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return  examenDao.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Examen findById(String password) {
		// TODO Auto-generated method stub
		return examenDao.findById(null).orElseGet(null);
	}

	@Override
	@Transactional 
	public Examen save(Examen examen) {
		// TODO Auto-generated method stub
		return examenDao.save(examen);
	}

	 

}

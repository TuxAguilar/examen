package com.backend.adea.org.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id; 
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
/**
 * @author mirif
 *
 */
@Entity
public class Examen implements Serializable{
		 
	private static final long serialVersionUID = 1L;

	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 private Integer id;
	 
	 @Column(name ="LOGIN")
	 private String login;
	 
	 @NotNull(message = "No puede estar vacio")
	 @Column(name ="PASSWORD")
	 private String password;
	 
	 @NotEmpty(message = "No puede estar vacio")
	 @Column(name ="NOMBRE")
	 private String nombre;
	 
	 @NotEmpty(message = "No puede estar vacio")
	 @Column(name ="CLIENTE")
	 private float cliente;
	 
	 @Email(message = "No es una dirección de correo bien formada")
	 @Column(name ="EMAIL")
	 private String email;
	 
	 @NotEmpty(message = "No puede estar vacio")
	 @Column(name ="FECHAALTA")
	 private Date fechaAlta;
	 
	 @Column(name ="FECHABAJA")
	 private Date fechaBaja;
	 
	 @NotEmpty(message = "No puede estar vacio")
	 @Column(name ="STATUS")
	 private char status;
	 
	 @NotEmpty(message = "No puede estar vacio")
	 @Column(name ="INTENTOS")
	 private float intentos;
	 
	 @Column(name ="FECHAREVOCADO")
	 private Date fechaRevocado;
	 
	 @Column(name ="FECHA_VIGENCIA")
	 private Date fechaVigencia;
	 
	 @Column(name ="NO_ACCESO")
	 private int noAcceso;
	 
	 @Column(name ="APELLIDO_PATERNO")
	 private String apellidoPaterno;
	 
	 @Column(name ="APELLIDO_MATERNO")
	 private String apellidoMaterno; 
	 
	 @Column(name ="AREA")
	 private int number;
	 
	 @NotEmpty(message = "No puede estar vacio")
	 @Column(name ="FECHAMODIFICACION")
	 private Date fechaModificacion;

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getCliente() {
		return cliente;
	}

	public void setCliente(float cliente) {
		this.cliente = cliente;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public Date getFechaBaja() {
		return fechaBaja;
	}

	public void setFechaBaja(Date fechaBaja) {
		this.fechaBaja = fechaBaja;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public float getIntentos() {
		return intentos;
	}

	public void setIntentos(float intentos) {
		this.intentos = intentos;
	}

	public Date getFechaRevocado() {
		return fechaRevocado;
	}

	public void setFechaRevocado(Date fechaRevocado) {
		this.fechaRevocado = fechaRevocado;
	}

	public Date getFechaVigencia() {
		return fechaVigencia;
	}

	public void setFechaVigencia(Date fechaVigencia) {
		this.fechaVigencia = fechaVigencia;
	}

	public int getNoAcceso() {
		return noAcceso;
	}

	public void setNoAcceso(int noAcceso) {
		this.noAcceso = noAcceso;
	}

	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	 
	 
	 


}

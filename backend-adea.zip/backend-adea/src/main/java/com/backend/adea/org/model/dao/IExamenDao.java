package com.backend.adea.org.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.backend.adea.org.entity.Examen;

public interface IExamenDao extends JpaRepository<Examen, Long>{

}

package com.backend.adea.org.model.service;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.backend.adea.org.entity.Examen;

public interface IExamenService {
	
	 public List<Examen> findAll();
		
	 public Page<Examen> findAll(Pageable pageable);
		
	 public Examen findById(String password);
	 	
	 public Examen save(Examen examen);
		
	 

}

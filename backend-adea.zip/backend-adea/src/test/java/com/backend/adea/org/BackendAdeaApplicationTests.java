package com.backend.adea.org;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendAdeaApplicationTests {

	@Test
	void contextLoads() {
	}

}
